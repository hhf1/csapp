import torch
import random
from pathlib import Path

# 导入diffuser中的pipeline
from diffusers import StableDiffusionPipeline

PROMPT_TEMPLETE = [
    "a photo of a {}",
    "a rendering of a {}",
    "a cropped photo of the {}",
    "the photo of a {}",
    "a photo of a clean {}",
    "a photo of a dirty {}",
    "a dark photo of the {}",
    "a photo of my {}",
    "a photo of the cool {}",
    "a close-up photo of a {}",
    "a bright photo of the {}",
    "a cropped photo of a {}",
    "a photo of the {}",
    "a good photo of the {}",
    "a photo of one {}",
    "a close-up photo of the {}",
    "a rendition of the {}",
    "a photo of the clean {}",
    "a rendition of a {}",
    "a photo of a nice {}",
    "a good photo of a {}",
    "a photo of the nice {}",
    "a photo of the small {}",
    "a photo of the weird {}",
    "a photo of the large {}",
    "a photo of a cool {}",
    "a photo of a small {}",
]

PROMPT_TEMPLETE = ["{}"]
pretrained_model_name_or_path = "/root/autodl-tmp/sd1-4bin"
output_dir = "./ti_res_emb000_loss/dog5"
instance_prompt = "dog"
s_prompt = "<dog5-s>"



pipe = StableDiffusionPipeline.from_pretrained(pretrained_model_name_or_path).to("cuda")

# pipe.load_textual_inversion("./ti_cat2", weight_name="learned_embeds.safetensors")
pipe.load_textual_inversion("./ti_emb000_dog5-s_", weight_name="learned_embeds.safetensors")
text_inputs_origin = pipe.tokenizer(
        instance_prompt,
        padding="max_length",
        max_length=pipe.tokenizer.model_max_length,
        truncation=True,
        return_tensors="pt",
    )
text_inputs_s = pipe.tokenizer(
        s_prompt,
        padding="max_length",
        max_length=pipe.tokenizer.model_max_length,
        truncation=True,
        return_tensors="pt",
    )
text_inputs_origin_ids = text_inputs_origin.input_ids
text_inputs_s_ids = text_inputs_s.input_ids
index = text_inputs_origin_ids[0][1]
index_s = text_inputs_s_ids[0][1]
prompt_embeds_new = 0
prompt_embeds_origin = 0
for template in PROMPT_TEMPLETE:
    text_inputs = pipe.tokenizer(
        template.format(instance_prompt),
        padding="max_length",
        max_length=pipe.tokenizer.model_max_length,
        truncation=True,
        return_tensors="pt",
    )
    text_input_ids = text_inputs.input_ids
    index_template = int(torch.where(text_input_ids[0] == index)[0][0])

    # 对ti的token进行编码得到text embedding
    text_inputs_s = pipe.tokenizer(
        template.format(s_prompt),
        padding="max_length",
        max_length=pipe.tokenizer.model_max_length,
        truncation=True,
        return_tensors="pt",
    )
    text_input_s_ids = text_inputs_s.input_ids
    index_template_s = int(torch.where(text_input_s_ids[0] == index_s)[0][0])
    # prompt_embeds_now = pipe.text_encoder(text_input_ids.to("cuda"), attention_mask=None)
    # prompt_embeds_now = prompt_embeds_now[0][0][index_template: index_template + 1]
    prompt_embeds = pipe.text_encoder(text_input_ids.to("cuda"), attention_mask=None)
    prompt_embeds = prompt_embeds[0][0][index_template: index_template + 1]
    prompt_embeds_now = pipe.text_encoder(text_input_s_ids.to("cuda"), attention_mask=None)
    prompt_embeds_now = prompt_embeds_now[0][0][index_template_s: index_template_s + 1]
    prompt_embeds_new += prompt_embeds_now
    prompt_embeds_origin += prompt_embeds

residual_save_path = output_dir + '/residual.pt'
torch.save((prompt_embeds_new - prompt_embeds_origin) / len(PROMPT_TEMPLETE), residual_save_path)