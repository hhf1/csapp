#!/bin/bash

# 定义模型名称和基础参数
export MODEL_NAME="/root/autodl-tmp/sd1-4bin"
export RESOLUTION=512
export TRAIN_BATCH_SIZE=1
export GRADIENT_ACCUMULATION_STEPS=4
export MAX_TRAIN_STEPS=3000
export LEARNING_RATE=5.0e-04
export LR_SCHEDULER="constant"
export LR_WARMUP_STEPS=0
export OUTPUT_DIR_PREFIX="ti_emb000"

# 数据集目录与对应的placeholder_token列表
declare -a DATASET_DIRS=(
    # "/root/autodl-tmp/Cones-V2-origin/paper_dataset/barn"
    # "/root/autodl-tmp/Cones-V2-origin/paper_dataset/chair"
    "/root/autodl-tmp/Cones-V2-origin/paper_dataset/cat2"
    "/root/autodl-tmp/Cones-V2-origin/paper_dataset/dog"
    "/root/autodl-tmp/Cones-V2-origin/paper_dataset/dog1"
    "/root/autodl-tmp/Cones-V2-origin/paper_dataset/dog2"
    "/root/autodl-tmp/Cones-V2-origin/paper_dataset/dog5"
    # "/root/autodl-tmp/Cones-V2-origin/paper_dataset/duck_toy"
    # "/root/autodl-tmp/Cones-V2-origin/paper_dataset/flower"
    # "/root/autodl-tmp/Cones-V2-origin/paper_dataset/monster_toy"
    # 添加其他数据集路径...
)
declare -a PLACEHOLDER_TOKENS=(
    # "<barn-s>"
    # "<chair-s>"
    "<cat2-s>"
    "<dog-s>"
    "<dog1-s>"
    "<dog2-s>"
    "<dog5-s>"
    # "<duck-s>"
    # "<flower-s>"
    # "<monster-s>"
    # 添加与数据集对应的placeholder_tokens...
)
declare -a INITIALIZER_TOKENS=(
    # "barn"
    # "chair"
    "cat"
    "dog"
    "dog"
    "dog"
    "dog"
    # "toy"
    # "flower"
    # "toy"
    # 添加与数据集对应的placeholder_tokens...
)
declare -a OTHER_TOKENS=(
    # "barn"
    # "chair"
    "dog"
    "cat"
    "cat"
    "cat"
    "cat"
    # "toy"
    # "flower"
    # "toy"
    # 添加与数据集对应的placeholder_tokens...
)

# 确保两个列表长度相同
if [ "${#DATASET_DIRS[@]}" -ne "${#PLACEHOLDER_TOKENS[@]}" ]; then
    echo "Error: The number of dataset directories and placeholder tokens must match."
    exit 1
fi

# 循环遍历每个数据集目录及其对应的token
for ((i=0; i<${#DATASET_DIRS[@]}; i++)); do
    DATASET_DIR="${DATASET_DIRS[$i]}"
    PLACEHOLDER_TOKEN="${PLACEHOLDER_TOKENS[$i]}"
    INITIALIZER_TOKEN="${INITIALIZER_TOKENS[$i]}"
    OTHER_TOKEN="${OTHER_TOKENS[$i]}"
    # 为每个数据集生成唯一的输出目录，包括placeholder_token以避免命名冲突
    OUTPUT_DIR="${OUTPUT_DIR_PREFIX}${PLACEHOLDER_TOKEN//[^a-zA-Z0-9_-]/_}"
    echo "Training on dataset: $DATASET_DIR, Output to: $OUTPUT_DIR, Placeholder Token: $PLACEHOLDER_TOKEN"

    # 执行训练命令
    accelerate launch ti_with_loss.py \
      --pretrained_model_name_or_path="$MODEL_NAME" \
      --train_data_dir="$DATASET_DIR" \
      --learnable_property="object" \
      --placeholder_token="$PLACEHOLDER_TOKEN" \
      --initializer_token="$INITIALIZER_TOKEN" \
      --resolution="$RESOLUTION" \
      --train_batch_size="$TRAIN_BATCH_SIZE" \
      --gradient_accumulation_steps="$GRADIENT_ACCUMULATION_STEPS" \
      --max_train_steps="$MAX_TRAIN_STEPS" \
      --learning_rate="$LEARNING_RATE" \
      --scale_lr \
      --lr_scheduler="$LR_SCHEDULER" \
      --lr_warmup_steps="$LR_WARMUP_STEPS" \
      --output_dir="$OUTPUT_DIR" \
      --other_tokens="$OTHER_TOKEN" 
    
    # 在每次训练后可根据需要添加额外的操作
    echo "Training one dataset"
done

echo "Finished training on all datasets with custom placeholder tokens."
