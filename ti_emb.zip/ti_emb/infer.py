import torch
import random
from pathlib import Path

# 导入diffuser中的pipeline
from diffusers import StableDiffusionPipeline
# 导入自定义的pipeline
# from ti_struct_pipeline import TiAndStructPipeline

# 导入diffusers自带的工具
from diffusers.utils import make_image_grid

# 导入自定义的工具函数
# from utils import ptp_utils, vis_utils

# 主函数入口，执行推理和生成过程
def main():
    # pipeline初始化
    pipeline = StableDiffusionPipeline.from_pretrained(
        "/root/autodl-tmp/sd1-4", torch_dtype=torch.float16
    ).to("cuda")

    # 加载ti新的embedding
    pipeline.load_textual_inversion("./ti_cat2_emb_loss", weight_name="learned_embeds.safetensors")
    # pipeline.load_textual_inversion("./ti_dog_emb_loss", weight_name="learned_embeds.safetensors")
    pipeline.load_textual_inversion("./ti_dog_emb_loss_015", weight_name="learned_embeds.safetensors")
    # pipeline.load_textual_inversion("./ti_dog_1-4", weight_name="learned_embeds.safetensors")

    # 输入prompt和一些必要的输入设置
    # prompt = "a <cat-s> and a <dog-s> on the table"
    # prompt = "a <dog-s> on the table"
    # prompt = "photo of a <dog-s> and cat"
    prompt = "photo of a <dog-s> and <cat-s>"
    # prompt = 'photo of a <cat-s>'
    # subject_dict = {"<cat-s>" : 2, "<dog-s>" : 5}
    # 最后结果输出的路径
    output_path = Path('./loss_test1')
    # print(pipeline.get_indices(prompt))
    # token_indices = [2, 5]
    images = []
    seeds = [random.randint(0, 1000) for _ in range(9)]
    for seed in seeds:
        print(f"Seed: {seed}")
        generator = torch.Generator('cuda').manual_seed(seed)
        image = pipeline(
            prompt=prompt,
            generator=generator,
            guidance_scale=7.5,
            num_inference_steps=50,
        ).images[0]
        prompt_output_path = output_path / prompt
        prompt_output_path.mkdir(exist_ok=True, parents=True)
        image.save(prompt_output_path / f'{seed}.png')
        images.append(image)
        # 可视化注意力图
        # attention_maps = pipeline.get_attention_map()
        # vis_utils.show_cross_attention(attention_maps=attention_maps,
		# 		                         path=prompt_output_path,
        #                                prompt=prompt,
        #                                tokenizer=pipeline.tokenizer,
        #                                res=16,
        #                                seed=seed,
        #                                from_where=("up", "down", "mid"),
        #                                indices_to_alter=token_indices,
        #                                orig_image=image)


    # save a grid of results across all seeds
    joined_image = make_image_grid(images, 3, 3)
    joined_image.save(output_path / f'{prompt}.png')

if __name__ == '__main__':
    main()

